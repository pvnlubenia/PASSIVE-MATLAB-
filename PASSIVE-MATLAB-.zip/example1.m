% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% Equation (2) in Feliu and Wiuf (2013): A simple reversible                %
%    Michaelis-Menten mechanism for activation of a substrate S             %
%                                                                           %
% RESULT: The network is injective.                                         %
%                                                                           %
% Reference: ﻿Feliu E, Wiuf C (2013) A computational method to preclude      %
%    multistationarity in networks of interacting species. Bioinformatics   %
%    29(18):2327--2334. ﻿https://doi.org/10.1093/bioinformatics/btt400       %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model = addReaction(model, 'S+E<->X', ...                  % just a visual guide on how the reaction looks like
                           {'S', 'E'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'X'}, {1}, [1], ...            % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                          % reversible or not
model = addReaction(model, 'X<->S*+E', ...
                           {'X'}, {1}, [1], ...
                           {'S*', 'E'}, {1, 1}, [1, 1], ...
                           true);

% Check if the network is injective
[injective, det_Mstar, model] = PLKinjective(model);

% Uncomment if you want the diagonal of the upper triangular matrix of the LU-decomposition
% [u, model] = PLKinjectiveLU(model);