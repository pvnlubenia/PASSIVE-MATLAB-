% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 2                                                              %
%                                                                           %
%                                                                           %
% Example 1 in Hernandez et al (2020)                                       %
%                                                                           %
% RESULT: The network is NOT injective.                                     %
%                                                                           %
% Reference: ﻿Hernandez B, Mendoza E, de los Reyes V A (2020) A              %
%    computational approach to multistationarity of power-law kinetics. J   %
%    Math Chem 58:56-87. https://doi.org/10.1007/s10910-019-01072-7         %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2';
model = addReaction(model, 'A1+A3->A1+A2', ...                    % just a visual guide on how the reaction looks like
                           {'A1', 'A3'}, {1, 1}, [0.5, 0.5], ...  % reactant species, stoichiometry, kinetic order
                           {'A1', 'A2'}, {1, 1}, [ ], ...         % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                                % reversible or not
model = addReaction(model, 'A1+A2->2A3', ...
                           {'A1', 'A2'}, {1, 1}, [1, 1], ...
                           {'A3'}, {2}, [ ], ...
                           false);
model = addReaction(model, '2A3->A1+A3', ...
                           {'A3'}, {2}, [1], ...
                           {'A1', 'A3'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'A3->0', ...
                           {'A3'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           false);
model = addReaction(model, 'A3->A3+A2', ...
                           {'A3'}, {1}, [1], ...
                           {'A3', 'A2'}, {1, 1}, [ ], ...
                           false);

% Check if the network is injective
[injective, det_Mstar, model] = PLKinjective(model);

% Uncomment if you want the diagonal of the upper triangular matrix of the LU-decomposition
% [u, model] = PLKinjectiveLU(model);